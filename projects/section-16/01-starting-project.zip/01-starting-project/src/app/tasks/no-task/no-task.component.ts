import { Component } from '@angular/core';

@Component({
  selector: 'app-no-task',
  standalone: true,
  templateUrl: './no-task.component.html',
  styleUrl: './no-task.component.css',
})
export class NoTaskComponent {}
